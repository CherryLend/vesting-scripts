#!/usr/bin/env python3


from config import *
from koios_api import get_address_info
import sqlite3


if __name__ == '__main__':
    """
    Connect to the database
    """
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()

    wallets = {}
    wallets_total_amount = 0
    wallets_total_amount_2 = 0
    records = 0
    with open(VESTING_FILE, 'r') as f:
        for line in f:
            if line.startswith('stake1') or line.startswith('addr1'):
                try:
                    records += 1
                    row = line.split(',')
                    address = row[0]
                    stake_total = int(row[2])  # * pow(10, DECIMALS)
                    stake_epoch_amount = int(row[3])  # * pow(10, DECIMALS)
                    stake_amount = 0
                    if address.startswith('addr1'):
                        address_info = get_address_info(address)
                        print(address_info)
                        stake_address = address_info[0]['stake_address']
                        print(address, stake_address)
                    else:
                        stake_address = address
                    wallets_total_amount += stake_total
                    amounts = {}
                    for i in range(START_EPOCH, START_EPOCH + EPOCHS_COUNT):
                        amounts[i] = stake_epoch_amount * 5
                        stake_amount += stake_epoch_amount * 5
                    amounts[START_EPOCH + EPOCHS_COUNT] = stake_total - stake_amount
                    stake_amount += stake_total - stake_amount
                    wallets_total_amount_2 += stake_total

                    if stake_address in wallets:
                        print(f"duplicate address {stake_address}!")
                        exit(1)

                    wallets[stake_address] = {
                        'stake_total': stake_total,
                        'amounts': amounts
                    }

                except Exception as e:
                    print(line)
                    print(f"Exception : {e}")
                    exit(1)

    print(f"{len(wallets)} wallets")
    total = 0
    for wallet in wallets:
        stake_total = wallets[wallet]['stake_total']
        amount_total = 0
        for epoch, amount in wallets[wallet]['amounts'].items():
            amount_total += amount
        print(wallet, stake_total, amount_total)
        total += amount_total
    print(f"Total from the input file:      {wallets_total_amount}")
    print(f"Total from the wallets amounts: {total}")

    print("Inserting the rewards into the database...")
    counter = 0
    total_amount = 0
    for stake_address in wallets:
        counter += 1
        wallet_rewards = 0
        # find out the wallet id and the stake address
        cur.execute("SELECT id FROM wallets WHERE stake_address = ?", (stake_address,))
        row = cur.fetchone()
        if row:
            # wallet found
            wallet_id = row[0]
        else:
            # wallet not found by stake address
            # inserting the new wallet
            cur.execute("INSERT INTO wallets(stake_address) VALUES (?)", (stake_address,))
            wallet_id = cur.lastrowid
            conn.commit()
        # now we need to add the rewards to the rewards_history table
        for epoch, rewards_amount in wallets[stake_address]['amounts'].items():
            total_amount += rewards_amount
            wallet_rewards += rewards_amount
            # find out how many epochs the rewards should be valid
            epochs_valid = EXPIRY_EPOCH - epoch
            cur.execute("SELECT count(*) FROM rewards_history "
                        "WHERE wallet_id = ? AND epoch = ?",
                        (wallet_id, epoch))
            nr = cur.fetchone()[0]
            if nr == 0:
                cur.execute("INSERT INTO rewards_history"
                            "(wallet_id, epoch, rewards_amount, epochs_valid) "
                            "VALUES(?, ?, ?, ?)",
                            (wallet_id, epoch, rewards_amount, epochs_valid))
            else:
                print(f"Wallet {stake_address} already found for epoch {epoch}")
                cur.execute("UPDATE rewards_history SET rewards_amount = ?, epochs_valid = ? "
                            "WHERE wallet_id = ? AND epoch = ?",
                            (rewards_amount, epochs_valid, wallet_id, epoch))
            conn.commit()

        print(f"[ {counter} / {records} ] {stake_address}: {wallet_rewards}")

    print("stake addresses: %d" % len(wallets))
    print("total rewards amount: %d" % total_amount)
