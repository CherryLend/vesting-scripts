from os import getcwd, getenv
mainnet = True

TOKEN = '75fcc276057db5fc48eae0e11453c773c8a54604c3086bf9d95ac1b7.43485259'  # CHRY
TICKER = 'CHRY'
DECIMALS = 6
START_EPOCH = 449
EPOCHS_COUNT = 145
EPOCHS_VALID_AFTER = 73
EXPIRY_EPOCH = START_EPOCH + EPOCHS_COUNT + EPOCHS_VALID_AFTER

workdir = getcwd()
base_path = workdir[0: workdir.find('src') - 1]

if mainnet:
    VM_BASE_URL = 'https://vm.adaseal.eu'
else:
    VM_BASE_URL = 'https://vmprev.adaseal.eu'

VM_TOKEN = getenv('VM_TOKEN', '')
DELIVER_LOG_FILE = base_path + '/log/deliver.log'
DB_FILE = base_path + '/db/database.db'
VESTING_FILE = base_path + '/doc/CHRY_vesting.csv'
