#!/usr/bin/env python3


from config import *
import os.path
import sqlite3


if __name__ == '__main__':

    if not os.path.exists(os.path.dirname(DB_FILE)):
        os.mkdir(os.path.dirname(DB_FILE))

    """
    Create the database tables if they don't exist
    """
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()

    """
    Wallets
    """
    print('Table wallets')
    cur.execute('''CREATE TABLE IF NOT EXISTS wallets (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                stake_address CHAR(56) NOT NULL
                )''')
    cur.execute('''CREATE UNIQUE INDEX IF NOT EXISTS wallets_stake_address ON wallets(stake_address)''')

    """
    Rewards history
    """
    print('Table rewards_history')
    cur.execute('''CREATE TABLE IF NOT EXISTS rewards_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                wallet_id INTEGER NUT NULL,
                epoch INTEGER NOT NULL DEFAULT 0,
                rewards_amount FLOAT NOT NULL DEFAULT 0,
                submitted INTEGER NOT NULL DEFAULT 0,
                submit_date TIMESTAMP,
                epochs_valid INTEGER NOT NULL DEFAULT 73
                )''')
    cur.execute('''CREATE UNIQUE INDEX IF NOT EXISTS rewards_history_wallet_id_epoch
                ON rewards_history(wallet_id, epoch)''')
    conn.close()
