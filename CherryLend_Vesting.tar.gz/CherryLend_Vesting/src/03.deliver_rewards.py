#!/usr/bin/env python3


from config import *
from koios_api.network import get_tip
import sqlite3
import requests
import json
import logging
import os
from time import sleep

TEST = False

if not os.path.exists(os.path.dirname(DELIVER_LOG_FILE)):
    os.mkdir(os.path.dirname(DELIVER_LOG_FILE))
logging.basicConfig(filename=DELIVER_LOG_FILE, format='%(asctime)s [%(levelname)s]: %(message)s', level=logging.DEBUG)


if __name__ == '__main__':

    tip = get_tip()
    logging.info('Current tip: %s' % tip)
    current_epoch = tip[0]['epoch_no']
    epoch = current_epoch

    headers = {'X-API-Token': VM_TOKEN}
    url = VM_BASE_URL + '/api.php'

    """
    Connect to the database
    """
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()

    """
    Read the rewards from the database
    """
    sql = "SELECT w.stake_address, rh.epoch, rh.rewards_amount, rh.submitted, rh.epochs_valid, rh.id " \
          "FROM rewards_history rh JOIN wallets w ON rh.wallet_id = w.id " \
          "WHERE rewards_amount - submitted > 0"
    cur.execute(sql)
    rows = cur.fetchall()
    total_rewards = 0
    deliver_count = 0
    count = 0
    errors = []
    reward = 0
    if TEST:
        print('== TEST mode ==')
        sleep(1)
    else:
        logging.debug('== LIVE mode ==')
        print('== LIVE mode ==')
        sleep(5)
    for row in rows:
        count += 1
        stake_address = row[0]
        epoch = row[1]
        reward = row[2] - row[3]
        epochs_valid = row[4] + epoch - current_epoch + 1
        project_locked = 'false'
        rh_id = row[5]
        if stake_address == '':
            logging.warning('Empty stake address!')
            continue
        if not TEST:
            logging.info(f"[ {count} / {len(rows)} ] Submitting the rewards for {stake_address} epoch {epoch}: "
                         f"{reward} {TICKER}...")
        else:
            print(f"[ {count} / {len(rows)} ] Submitting the rewards for {stake_address} epoch {epoch}: "
                  f"{reward} {TICKER}...")
        total_rewards += reward
        deliver_count += 1
        req_data = {
            'action': 'deliver_reward',
            'staking_address': stake_address,
            'token_id': TOKEN,
            'amount': str(reward * pow(10, DECIMALS)),
            'overcommit': 'true',
            'expiry': str(epochs_valid),
            'return_policy': '0',
            'unlocks_on': str(epoch),
            'project_locked': project_locked
        }
        if not TEST:
            # submit the rewards to the Vending Machine and update the database
            sql = "UPDATE rewards_history SET submitted = submitted + ? WHERE id = ?"
            cur.execute(sql, (reward, rh_id))
            try:
                response = json.loads(requests.post(url, headers=headers, data=req_data).text)
                if json.dumps(response) == '{"success": true}':
                    conn.commit()
                else:
                    logging.warning(json.dumps(response))
                    logging.warning('rollback!')
                    conn.rollback()
                    total_rewards -= reward
                    errors.append(json.dumps(response))
            except Exception as e:
                logging.exception(e)
                logging.error('rollback!')
                conn.rollback()
                total_rewards -= reward
        else:
            # print the request data
            print(json.dumps(req_data))

    if not TEST:
        logging.info('Total submitted rewards: ')
        logging.info(f"{TICKER}: {total_rewards} {deliver_count} deliveries)")
        if errors:
            logging.error(errors)
    else:
        print('Total submitted rewards: ')
        print(f"{TICKER}: {total_rewards} {deliver_count} deliveries)")
